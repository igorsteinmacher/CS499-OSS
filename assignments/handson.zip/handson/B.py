class B:
    pass
