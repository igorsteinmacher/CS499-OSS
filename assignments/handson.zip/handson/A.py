class A:
    pass
